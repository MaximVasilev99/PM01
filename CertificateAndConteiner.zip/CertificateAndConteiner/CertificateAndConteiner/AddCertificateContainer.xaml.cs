﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CertificateAndConteiner
{
    /// <summary>
    /// Логика взаимодействия для AddCertificateContainer.xaml
    /// </summary>
    public partial class AddCertificateContainer : Window
    {
        public AddCertificateContainer()
        {
            InitializeComponent();
            using (var db = new MKYBEntities())
            {
                NCB.ItemsSource = db.Certificate.Select(p => p.Name).ToList();
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new MKYBEntities())
                {
                    var nExp = new CertificateContainer();
                    nExp.Name = NT.Text;
                    var userr = db.Certificate.FirstOrDefault(p => p.Name == NCB.Text);
                    if (userr != null)
                    {
                        nExp.CertificateID = userr.ID;
                    }
                    db.CertificateContainer.Add(nExp);
                    db.SaveChanges();
                    MessageBox.Show("Запись добавлена.");
                    NT.Text = "";
                    NCB.Text = "";

                }
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new MKYBEntities())
                {
                    var nExp = new CertificateContainer();
                    nExp.Name = NT.Text;
                    var userr = db.Certificate.FirstOrDefault(p => p.Name == NCB.Text);
                    if (userr != null)
                    {
                        nExp.CertificateID = userr.ID;
                    }
                    db.CertificateContainer.Add(nExp);
                    db.SaveChanges();
                    MessageBox.Show("Запись добавлена.");
                    CertificateContainerWin br = new CertificateContainerWin();
                    br.Show();
                    this.Close();

                }
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            CertificateContainerWin br = new CertificateContainerWin();
            br.Show();
            this.Close();
        }
    }
}
