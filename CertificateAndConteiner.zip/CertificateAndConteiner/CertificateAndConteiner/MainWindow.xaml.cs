﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CertificateAndConteiner
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (ParT.Visibility == Visibility.Collapsed)
            {
                ParrT.Visibility = Visibility.Collapsed; //This hides the PasswordBox
                ParT.Visibility = Visibility.Visible; //This shows the TextBox
                ParT.Text = new NetworkCredential(string.Empty, ParrT.SecurePassword).Password; //This sets the text to the TextBox to the password typed into the PasswordBox
                ParT.Focus();
            }
            else
            {
                ParrT.Visibility = Visibility.Visible; //This shows the PasswordBox
                ParT.Visibility = Visibility.Collapsed; //This hides the TextBox

                ParrT.Password = new NetworkCredential(string.Empty, ParT.Text).Password; //This sets the text to the TextBox to the password typed into the PasswordBox

                ParrT.Focus();
            }
        }
        //Авторизация
        private void vhod_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new MKYBEntities())
                {
                    var usern = db.User.FirstOrDefault(user => user.Login == log.Text && user.Password == ParrT.Password); // взятие информации из бд
                    if (usern == null) // проверка есть ли таккие данные
                    {
                        MessageBox.Show("Неверно введен логин или пароль");
                    }
                    else
                    if (usern.Role == 1)
                    {
                        CertificateWin fn = new CertificateWin();
                        fn.Show();
                        this.Close();
                    }
                    else
                    {
                        CertificateWin br = new CertificateWin();
                        br.Show();
                        this.Close();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }

        }
    }
}
