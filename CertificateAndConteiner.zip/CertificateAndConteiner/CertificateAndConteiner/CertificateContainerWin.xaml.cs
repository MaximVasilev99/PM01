﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CertificateAndConteiner
{
    /// <summary>
    /// Логика взаимодействия для CertificateContainerWin.xaml
    /// </summary>
    public partial class CertificateContainerWin : Window
    {
        public CertificateContainerWin()
        {
            InitializeComponent();
            using (var db = new MKYBEntities())
            {
                D_G.ItemsSource = db.CertificateContainer.ToList();
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow br = new MainWindow();
            br.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            CertificateWin br = new CertificateWin();
            br.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            AddCertificateContainer br = new AddCertificateContainer();
            br.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new MKYBEntities())
                {
                    var del = (CertificateContainer)D_G.SelectedItem;
                    var user = db.CertificateContainer.FirstOrDefault(dd => dd.ID == del.ID);
                    db.CertificateContainer.Remove(user);
                    db.SaveChanges();
                    var officeList = db.CertificateContainer.ToList();
                    D_G.ItemsSource = officeList;
                    MessageBox.Show("Запись удалена");
                }
            }
            catch
            {
                MessageBox.Show("Ошибка.");
            }
        }
    }
}
