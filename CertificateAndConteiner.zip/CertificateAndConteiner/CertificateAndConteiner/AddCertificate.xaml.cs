﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CertificateAndConteiner
{
    /// <summary>
    /// Логика взаимодействия для AddCertificate.xaml
    /// </summary>
    public partial class AddCertificate : Window
    {
        public AddCertificate()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CertificateWin br = new CertificateWin();
            br.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new MKYBEntities())
                {
                    var nExp = new Certificate();
                    nExp.Name = NT.Text;
                    nExp.Owner = OT.Text;
                    nExp.ValidFrom = VFT.SelectedDate;
                    nExp.ValidUntil = VUT.SelectedDate;
                    db.Certificate.Add(nExp);
                    db.SaveChanges();
                    MessageBox.Show("Запись добавлена.");

                    CertificateWin br = new CertificateWin();
                    br.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new MKYBEntities())
                {
                    var nExp = new Certificate();
                    nExp.Name = NT.Text;
                    nExp.Owner = OT.Text;
                    nExp.ValidFrom = VFT.SelectedDate;
                    nExp.ValidUntil = VUT.SelectedDate;
                    db.Certificate.Add(nExp);
                    db.SaveChanges();
                    MessageBox.Show("Запись добавлена.");
                    NT.Text = "";
                    OT.Text = "";
                    VFT.Text = "";
                    VFT.Text = "";
                }
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }

        }
    }
}
