﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CertificateAndConteiner
{
    /// <summary>
    /// Логика взаимодействия для CertificateWin.xaml
    /// </summary>
    public partial class CertificateWin : Window
    {
        public CertificateWin()
        {
            InitializeComponent();
            using (var db = new MKYBEntities())
            {
                D_G.ItemsSource = db.Certificate.ToList();
            }

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow br = new MainWindow();
            br.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            AddCertificate br = new AddCertificate();
            br.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            CertificateContainerWin br = new CertificateContainerWin();
            br.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new MKYBEntities())
                {
                    var del = (Certificate)D_G.SelectedItem;
                    var user = db.Certificate.FirstOrDefault(dd => dd.ID == del.ID);
                    db.Certificate.Remove(user);
                    db.SaveChanges();
                    var officeList = db.Certificate.ToList();
                    D_G.ItemsSource = officeList;
                    MessageBox.Show("Запись удалена");
                }
            }
            catch
            {
                MessageBox.Show("Ошибка.");
            }
        }
    }
}
